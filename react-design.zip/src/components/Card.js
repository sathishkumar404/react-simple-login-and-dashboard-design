import React, { Component } from 'react';

class Card extends Component {
    render() {
        return (
          <div>
            <div className="col-sm-12 col-md-4">
              <div className="card">
                <div className="card-header">
                  <h4 className="card-title"></h4>
                </div>
                <div className="card-content">
                 
                </div>
              </div>
            </div>
          </div>
        );
    }
}

export default Card;