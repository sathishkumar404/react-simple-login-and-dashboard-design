import React, { Component } from 'react';

class NavHeader extends Component {
    render() {
        return (
          <div>
            
          </div>
        );
    }
}

export default NavHeader;